// How to run the code in terminal
$ gcc -o smallsh smallsh.c
$ ./smallsh

// How to run the testing script
// after compiling
$ chmod +x ./p3testscript
$ p3testscript 2>&1
